# 🚨 СРОЧНЫЕ ИСПРАВЛЕНИЯ - КРАТКАЯ ИНСТРУКЦИЯ

## ⚠️ КРИТИЧЕСКИ ВАЖНО!
**Вы опубликовали пароль от сервера в открытом виде!**
Немедленно смените пароль: `passwd root`

---

## ✅ Что было исправлено в коде:

1. ✅ **Удален дублирующийся эндпоинт** GET /api/venues
2. ✅ **Настроен пул соединений** (max: 20, min: 2, timeout: 30s)
3. ✅ **Добавлен rollback** в транзакциях PUT /api/flavors
4. ✅ **Проверка JWT_SECRET** при запуске
5. ✅ **Создан .env.local.example** с шаблоном настроек

---

## 🚀 БЫСТРЫЙ ДЕПЛОЙ (3 команды):

### На локальной машине:
```bash
cd /workspaces/Tabak_Multiuser
tar -czf deploy-fix.tar.gz server/ .env.local.example health-check.sh
scp deploy-fix.tar.gz root@103.88.241.78:/tmp/
```

### На сервере (после смены пароля!):
```bash
cd /home/tabakapp/apps/tabak_multiuser && \
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz server/ && \
tar -xzf /tmp/deploy-fix.tar.gz && \
chmod +x health-check.sh && \
pm2 restart tabak-api && \
pm2 logs tabak-api --lines 20
```

---

## 🔍 Проверка после деплоя:

```bash
# Запустить проверку здоровья системы
cd /home/tabakapp/apps/tabak_multiuser
./health-check.sh
```

Если все ОК - увидите зеленые галочки ✓

---

## 📋 Обязательная проверка .env.local:

```bash
cd /home/tabakapp/apps/tabak_multiuser

# Если файла нет - создать из примера
if [ ! -f .env.local ]; then
    cp .env.local.example .env.local
    nano .env.local  # Отредактировать значения!
fi

# Проверить содержимое
cat .env.local
```

**Обязательно должны быть:**
- `DATABASE_URL=postgresql://user:pass@host:5432/dbname`
- `JWT_SECRET=` (сгенерировать: `openssl rand -base64 32`)
- `PORT=3000`

После изменений: `pm2 restart tabak-api`

---

## 📚 Подробная документация:

- 📄 [FIX_SUMMARY.md](FIX_SUMMARY.md) - Полный отчет об исправлениях
- 🔍 [DIAGNOSTICS.md](DIAGNOSTICS.md) - Подробная диагностика проблем
- ⚙️ [.env.local.example](.env.local.example) - Шаблон конфигурации

---

## 🆘 Если проблемы остались:

```bash
# Собрать логи для анализа
pm2 logs tabak-api --lines 100 > /tmp/api-logs.txt
tail -100 /var/log/nginx/error.log > /tmp/nginx-logs.txt
systemctl status postgresql > /tmp/db-status.txt
```

Отправьте эти файлы для дальнейшей помощи.

---

## ✅ Контрольный чек-лист:

- [ ] Пароль root изменен
- [ ] Файлы обновлены на сервере
- [ ] .env.local проверен/создан
- [ ] JWT_SECRET установлен (не дефолтный!)
- [ ] PM2 перезапущен
- [ ] ./health-check.sh показывает ✓✓✓
- [ ] curl http://localhost:3000/api/test работает
- [ ] curl http://localhost:3000/api/venues возвращает данные

**Если все пункты ✓ - система работает!**
