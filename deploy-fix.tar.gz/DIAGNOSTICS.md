# 🔍 Диагностика и исправление проблем на сервере

## ⚠️ КРИТИЧЕСКАЯ ПРОБЛЕМА БЕЗОПАСНОСТИ
**ВЫ ОПУБЛИКОВАЛИ ПАРОЛЬ ОТ СЕРВЕРА В ОТКРЫТОМ ВИДЕ!**

### 🚨 Срочно измените пароль:
```bash
passwd root
```

---

## 📝 Команды для диагностики проблем

### 1. Подключитесь к серверу (ПОСЛЕ СМЕНЫ ПАРОЛЯ):
```bash
ssh root@103.88.241.78
```

### 2. Проверьте статус PM2 процессов:
```bash
pm2 list
pm2 logs tabak-api --lines 50
```

### 3. Проверьте подключение к базе данных:
```bash
# Проверить что PostgreSQL запущен
systemctl status postgresql

# Попробовать подключиться к БД
psql -U tabakapp -d appdb -c "SELECT COUNT(*) FROM venues;"
```

### 4. Проверьте переменные окружения:
```bash
cd /home/tabakapp/apps/tabak_multiuser
cat .env.local

# Убедитесь что есть:
# - DATABASE_URL
# - JWT_SECRET (не дефолтное значение!)
# - GEMINI_API_KEY (если используется)
```

### 5. Проверьте логи Nginx:
```bash
tail -100 /var/log/nginx/error.log
tail -100 /var/log/nginx/access.log
```

### 6. Проверьте порты:
```bash
netstat -tulpn | grep :3000  # API должен слушать на порту 3000
netstat -tulpn | grep :80    # Nginx должен слушать на 80
netstat -tulpn | grep :443   # Nginx должен слушать на 443
```

---

## 🔧 Исправленные проблемы в коде:

### ✅ 1. Удален дублирующийся эндпоинт GET /api/venues
- Было два одинаковых эндпоинта с разными запросами
- Оставлен улучшенный с COALESCE(title, name)

### ✅ 2. Добавлены настройки пула соединений
```javascript
max: 20,                    // максимум соединений
min: 2,                     // минимум соединений
idleTimeoutMillis: 30000,   // закрывать неиспользуемые через 30 сек
connectionTimeoutMillis: 10000 // таймаут подключения 10 сек
```

### ✅ 3. Исправлена обработка ошибок в транзакциях
- Добавлен ROLLBACK при ошибках в PUT /api/flavors
- Гарантированное освобождение клиентов через finally

### ✅ 4. Добавлена проверка JWT_SECRET
- Выводится предупреждение если используется дефолтный ключ

### ✅ 5. Создан .env.local.example
- Шаблон для настройки переменных окружения

---

## 🚀 Деплой исправлений на сервер:

### Шаг 1: Создать архив с обновлениями
```bash
# На локальной машине
cd /workspaces/Tabak_Multiuser
tar -czf deploy-fix.tar.gz server/ .env.local.example
```

### Шаг 2: Загрузить на сервер
```bash
scp deploy-fix.tar.gz root@103.88.241.78:/tmp/
```

### Шаг 3: Установить на сервере
```bash
ssh root@103.88.241.78

# Бэкап текущих файлов
cd /home/tabakapp/apps/tabak_multiuser
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz server/

# Распаковать обновления
tar -xzf /tmp/deploy-fix.tar.gz

# Проверить/создать .env.local (если его нет)
if [ ! -f .env.local ]; then
    cp .env.local.example .env.local
    echo "⚠️ ВАЖНО: Отредактируйте .env.local и добавьте правильные значения!"
    nano .env.local
fi

# Перезапустить API
pm2 restart tabak-api
pm2 logs tabak-api
```

### Шаг 4: Проверить что всё работает
```bash
# Тест API
curl http://localhost:3000/api/test

# Тест venues
curl http://localhost:3000/api/venues

# Проверить логи
pm2 logs tabak-api --lines 20
```

---

## 🔍 Типичные проблемы и решения:

### Проблема: "Database connection failed"
**Решение:**
```bash
# Проверить DATABASE_URL в .env.local
cat .env.local | grep DATABASE_URL

# Проверить что PostgreSQL работает
systemctl status postgresql

# Проверить права доступа пользователя БД
psql -U postgres -c "\\du tabakapp"
```

### Проблема: "Pool exhausted" (закончились соединения)
**Решение:**
```bash
# Перезапустить API
pm2 restart tabak-api

# После обновления кода проблема должна исчезнуть
# (добавлены настройки пула и правильное освобождение клиентов)
```

### Проблема: "502 Bad Gateway" от Nginx
**Решение:**
```bash
# Проверить что API запущен
pm2 list

# Проверить логи Nginx
tail -50 /var/log/nginx/error.log

# Перезапустить Nginx
systemctl restart nginx
```

### Проблема: "JWT verification failed"
**Решение:**
```bash
# Установить сильный JWT_SECRET в .env.local
# Сгенерировать новый:
openssl rand -base64 32

# Добавить в .env.local:
echo "JWT_SECRET=$(openssl rand -base64 32)" >> .env.local

# Перезапустить API
pm2 restart tabak-api
```

---

## 📊 Мониторинг после исправлений:

```bash
# Следить за логами в реальном времени
pm2 logs tabak-api

# Проверить использование памяти
pm2 monit

# Проверить что нет утечек соединений
# (количество должно быть стабильным после запуска)
watch -n 5 'psql -U postgres -c "SELECT count(*) FROM pg_stat_activity WHERE datname='\''appdb'\'';"'
```

---

## 📞 Если проблемы остались:

1. Соберите логи:
```bash
pm2 logs tabak-api --lines 100 > /tmp/api-logs.txt
tail -100 /var/log/nginx/error.log > /tmp/nginx-logs.txt
psql -U tabakapp -d appdb -c "SELECT version();" > /tmp/db-info.txt
```

2. Проверьте статус всех сервисов:
```bash
systemctl status nginx postgresql
pm2 list
```

3. Отправьте вывод этих команд для дальнейшей диагностики
